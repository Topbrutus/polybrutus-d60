# Polybrutus 59D — Exact 64-point Euclidean metric and fifty-threefold ideal graph mode

**Human scientific author:** Gabriel St-Pierre, independent researcher.
**Material AI assistance:** OpenAI ChatGPT (Astra) materially assisted independent exact rational programs, verification, scientific manuscript, metadata and controlled publication. AI is not the scientific author.

## Exact reproducible mathematical results

- **64** unit-norm points, **2016 / 2016** labelled exact rational squared-distance pairs.
- **1953 / 1953** labelled predecessor D58 distances conserved; **63** added squared distances each **2R²**.
- PSD rational Euclidean Gram and PSD centered Gram of exact **affine rank 59**, minimal Euclidean dimension for this synthetic metric, with 60 coordinate storage.
- Full normalized histogram \`k=4d²/R²\`, R=1: 4:6, 7:2, 8:1985, 9:3, 10:10, 12:6, 13:2, 16:2. Exact sum R=1: **16175/4**.
- Separately freely stipulated dimensionless ideal equal-scalar-mass weighted complete graph \`w_ij=1/d_ij²\`: eigenvalue **32 multiplicity 53**, and **63/2 multiplicity 4**. Not observed hertz.
- Two independent exact rational implementations and four primary adversarial negative controls, authentication of full original D58 source tag archive and original certificate by SHA256/CRC.

Reproduce using Python 3.12, sympy==1.14.0:

    python -m pip install sympy==1.14.0
    python src/verify_d59.py
    python tests/independent_d59.py
    python src/check_zenodo_metadata.py

Both verifiers reproduce the identical deterministic certificate \`results/certificate_d59.json\`. GitHub Actions executes both exact verifiers, deterministic certificate check and current bibliography metadata QA.

## Only original frozen scientific parent

[Polybrutus D58 v0.1.0](https://github.com/Topbrutus/polybrutus-d58/tree/v0.1.0), true peeled commit \`d5b40891021bc60358fed4c61cc39af082bec137\`, DOI [10.5281/zenodo.24431283](https://doi.org/10.5281/zenodo.24431283). Its **entire original full scientific Git tag ZIP**, including all older original source ZIP archives nested unchanged, is embedded byte-identically at \`prior/d58/frozen_scientific_tag_v0.1.0.zip\` SHA256 \`4a70bd76f4351c2be4f936cea26d07793bcd1cc66eb5533789633dc30ff305bb\`; original D58 certificate remains byte-identical SHA256 \`972ab25e27dd00ccdd030905683b167699b5cdcb7d3f8f48a6c760f83eeed0c1\`.

Official Zenodo metadata must include nine D59-specific keywords (\`fifty-nine\`, \`fifty-threefold\`), structured \`isDerivedFrom\` direct D58 DOI 10.5281/zenodo.24431283 and **separate** bibliographic references to D58 and historic D7 DOI 10.5281/zenodo.24407952.

[Specification](SPECIFICATION_D59.md) | [constructive proof](PREUVE_D59.md) | [provenance](PROVENANCE.md) | [references](REFERENCES.md) | [two-page PDF](publication/POLYBRUTUS_59D_NOTE.pdf).

**Scope:** This establishes one synthetic exact Euclidean labelled metric and a separately stipulated dimensionless ideal weighted graph, not observed physical spacetime dimensions, measured hertz, newly discovered particles, a universal mathematical theorem or independent human peer review. **Software MIT, manuscript CC BY 4.0.**
