# Polybrutus D59 — immutable full source lineage and AI disclosure

**Human scientific author:** Gabriel St-Pierre, independent researcher. OpenAI ChatGPT (Astra) materially assisted independent rational verification programs, mathematical writing and controlled publication; AI is not the scientific author.

**Sole direct scientific parent:** Topbrutus/polybrutus-d58@v0.1.0, true peeled SHA \`d5b40891021bc60358fed4c61cc39af082bec137\`, DOI 10.5281/zenodo.24431283. Entire original scientific Git source ZIP \`prior/d58/frozen_scientific_tag_v0.1.0.zip\`: **3634955 bytes, 32 entries, ZIP CRC PASS**, SHA256 \`4a70bd76f4351c2be4f936cea26d07793bcd1cc66eb5533789633dc30ff305bb\`. All original ancestor full source ZIP archives remain nested byte-identically. Original certificate \`prior/d58/results/certificate_d58.json\`: **148056 bytes**, SHA256 \`972ab25e27dd00ccdd030905683b167699b5cdcb7d3f8f48a6c760f83eeed0c1\`, copied unchanged. Both D59 programs authenticate ZIP SHA/CRC, original certificate bytes and every one of **1953** old labelled squared-distance values.

**Historical discrepancy disclosed since D48:** original D47 certificate contains an incorrect textual D46 grandparent Git commit. All original source archives remain unchanged; the direct D58 tag is independently authenticated. Any CRLF/LF text normalization is permitted for comparison of ZIP contents to Git blobs only, never a rewrite of the original ZIP.

Zenodo requires structured \`isDerivedFrom\` direct D58 DOI 10.5281/zenodo.24431283 and separate D58/D7 references 10.5281/zenodo.24407952.
**Limits:** This establishes one synthetic exact Euclidean labelled metric and a separately stipulated dimensionless ideal weighted graph, not observed physical spacetime dimensions, measured hertz, newly discovered particles, a universal mathematical theorem or independent human peer review.
