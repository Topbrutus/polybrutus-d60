# Polybrutus D59 — proof-first validation and controlled publication

1. Direct scientific parent D58 frozen v0.1.0 peeled Git commit d5b40891021bc60358fed4c61cc39af082bec137, DOI 10.5281/zenodo.24431283, entire original source ZIP SHA256 4a70bd76f4351c2be4f936cea26d07793bcd1cc66eb5533789633dc30ff305bb, certificate SHA256 972ab25e27dd00ccdd030905683b167699b5cdcb7d3f8f48a6c760f83eeed0c1. Both exact programs validate original ZIP SHA/CRC, original certificate bytes and inherited labels.
2. Exhaust all 64 norm-one points and 2016 labelled exact squared distances; 1953 unchanged old D58 pairs and 63 new squared distances 2R²; Euclidean Gram and centered Gram PSD rank 59.
3. Two independent implementations (SymPy exact Gram vs fractions.Fraction separate pair rules), four adversarial negative controls, exact deterministic certificate. Chosen dimensionless ideal graph eigenvalue 32 mult 53 and 63/2 mult 4.
4. Scientific GitHub initial main CI must pass, then freeze source tag v0.1.0 and require tag CI green; after public Zenodo DOI document on main and require third green CI.
5. Public Zenodo originals: full frozen Git scientific source ZIP, two-page mathematical PDF and exact deterministic certificate JSON; all 3 filenames, sizes and MD5 from public API match SHA256-verified originals. Nine current D59 fifty-nine/fifty-threefold keywords, structured isDerivedFrom direct D58 DOI, separate D58/D7 textual bibliography.
6. Preserve entire historic original source ZIP nesting unchanged, disclose D47/D46 historical parent text SHA mistake, never claim physical spacetime, measured hertz or new universal theorem.

    python -m pip install sympy==1.14.0
    python src/verify_d59.py
    python tests/independent_d59.py
    python src/check_zenodo_metadata.py
