# Polybrutus D59 — exact 64-point labelled Euclidean squared-distance metric

**Exclusive direct parent scientific source:** Topbrutus/polybrutus-d58@v0.1.0, actual peeled scientific Git commit \`d5b40891021bc60358fed4c61cc39af082bec137\`, DOI 10.5281/zenodo.24431283, original full source ZIP SHA256 \`4a70bd76f4351c2be4f936cea26d07793bcd1cc66eb5533789633dc30ff305bb\`, original D58 certificate SHA256 \`972ab25e27dd00ccdd030905683b167699b5cdcb7d3f8f48a6c760f83eeed0c1\`.

## Conservative perpendicular norm-one extension

Embed all 63 predecessor norm-one vectors p_i as q_i=(p_i,0). Append one perpendicular unit vector q_64. Every one of C(63,2)=1953 old labelled squared distances remains unchanged; all 63 new squared distances equal 2R². Total C(64,2)=2016 labelled unordered pairs.

Construct a rational Gram G as orthogonal sum of seven original canonical norm-one points (Gram rank 3), a separate centered five-point regular unit simplex (rank 4) with mutual inner products -1/4, and **52** independent mutually orthogonal norm-one axes (rank 52). Hence G=XXᵀ is PSD, unit diagonal, exact rank **3+4+52=59**. Set D_ii=0 and D_ij=2-2G_ij. With H=I-11ᵀ/64, B=-(HDH)/2=HGH is PSD of rank **59**. An inherited canonical antipodal point pair implies the origin lies in the affine hull. Minimum affine Euclidean dimension of this particular metric is therefore 59 (60 coordinate storage).

At R=1, \`k=4d²/R²\` exact histogram: 4:6, 7:2, 8:1985, 9:3, 10:10, 12:6, 13:2, 16:2; total 2016. Exact sum of squared pair distances R=1: **16175/4**.

## Independently stipulated ideal weighted graph

Freely choose scalar unit masses, weighted complete edges w_ij=1/d_ij². New point connects to all 63 old points with weight 1/2. The chosen ideal Laplacian is L59=[[L58+I63/2,-1_63/2],[-1_63ᵀ/2,63/2]]. Its characteristic recurrence is chi64(z)=z(z-32)chi63(z-1/2)/(z-1/2).
Using the inherited seven-point factor f6(z)=chiP7(z)/z:
chi64(z)=z(z-32)^53(z-63/2)^4*f6(z-57/2).
Exact rational nullities yield Laplacian eigenvalue **32 multiplicity 53**, and **63/2 multiplicity 4**. These values are dimensionless model eigenmodes, not physical frequencies.

**Bibliography:** immediate D58 DOI 10.5281/zenodo.24431283; historical D7 DOI 10.5281/zenodo.24407952.
