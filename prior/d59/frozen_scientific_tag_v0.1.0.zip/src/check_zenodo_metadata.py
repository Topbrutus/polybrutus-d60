#!/usr/bin/env python3
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
c=json.loads((R/'results/certificate_d59.json').read_text('utf8'))
m=json.loads((R/'publication/zenodo_metadata_blueprint.json').read_text('utf8'))
assert c['status']=='PASS' and c['dimension']==m['scientific_dimension']==59
assert c['vertices']==m['norm_one_vertices']==64
assert c['pairs']==m['exact_labelled_squared_pairs']==2016
assert c['affine_rank']==c['centered_gram_rank']==59
assert c['eigenvalue_32_multiplicity']==m['model_eigenvalue_32_multiplicity']==53
assert c['eigenvalue_63_over_2_multiplicity']==m['model_eigenvalue_63_over_2_multiplicity']==4
assert c['parent_tag_commit']=='d5b40891021bc60358fed4c61cc39af082bec137'
assert c['parent_doi']==m['scientific_parent_doi']=='10.5281/zenodo.24431283'
assert m['related_identifiers']==[{'identifier':'10.5281/zenodo.24431283','relation':'isDerivedFrom','resource_type':'publication-preprint','scheme':'doi'}]
assert len(m['keywords'])==9
assert 'affine Euclidean dimension fifty-nine' in m['keywords']
assert 'fifty-threefold ideal eigenvalue' in m['keywords']
assert len(m['references'])==2
assert '10.5281/zenodo.24431283' in m['references'][0]
assert '10.5281/zenodo.24407952' in m['references'][1]
assert not any(x in str(m['keywords']) for x in ('fifty-eight','fifty-twofold','sixty','fifty-fourfold'))
note=(R/'publication/POLYBRUTUS_59D_NOTE.md').read_text('utf8')
assert all(x in note for x in ('## References','10.5281/zenodo.24431283','10.5281/zenodo.24407952'))
print('D59_CURRENT_9_KEYWORDS_STRUCTURED_DIRECT_D58_PARENT_AND_SEPARATE_D58_D7_REFERENCES_PASS')
