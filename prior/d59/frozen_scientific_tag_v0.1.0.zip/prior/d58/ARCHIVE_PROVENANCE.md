# Polybrutus D58 — complete original frozen scientific source

- Direct parent original tag: https://github.com/Topbrutus/polybrutus-d58/tree/v0.1.0, peeled commit \`d5b40891021bc60358fed4c61cc39af082bec137\`.
- Zenodo DOI 10.5281/zenodo.24431283.
- Full original source \`frozen_scientific_tag_v0.1.0.zip\`: **3634955 bytes**, **32 entries**, ZIP CRC PASS, SHA256 \`4a70bd76f4351c2be4f936cea26d07793bcd1cc66eb5533789633dc30ff305bb\`.
- Exact original \`results/certificate_d58.json\`: **148056 bytes**, SHA256 \`972ab25e27dd00ccdd030905683b167699b5cdcb7d3f8f48a6c760f83eeed0c1\`.
- All ancestor original complete source ZIPs remain embedded without modification, including original historical D47/D46 textual SHA inconsistency disclosed since D48.
