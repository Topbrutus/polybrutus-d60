# Polybrutus D59 — prior same-author mathematical publications

These are earlier same-author works, **not independent external peer review**.

[1] St-Pierre, Gabriel (2026). *Polybrutus 58D: Exact 63-Point Euclidean Metric and Fifty-Twofold Ideal Graph Mode*. Zenodo DOI [10.5281/zenodo.24431283](https://doi.org/10.5281/zenodo.24431283). Direct immutable scientific parent. Frozen [Git source D58 v0.1.0](https://github.com/Topbrutus/polybrutus-d58/tree/v0.1.0), peeled scientific commit d5b40891021bc60358fed4c61cc39af082bec137.

[2] St-Pierre, Gabriel (2026). *Polybrutus 7D: An Exact Twelve-Point Orthogonal Completion, the 12-35-37 Identity, and an Oscillator Model*. Zenodo DOI [10.5281/zenodo.24407952](https://doi.org/10.5281/zenodo.24407952). Historical reference, not immediate parent.

[3] St-Pierre, Gabriel (2026). Complete original Polybrutus D58 frozen scientific source v0.1.0, https://github.com/Topbrutus/polybrutus-d58/tree/v0.1.0, original entire ZIP SHA256 \`4a70bd76f4351c2be4f936cea26d07793bcd1cc66eb5533789633dc30ff305bb\`, archived untouched within D59.

Official Zenodo: exactly nine current \`fifty-nine\` / \`fifty-threefold\` keywords, structured \`isDerivedFrom\` direct D58 DOI, two separate bibliographic entries D58 and D7.
